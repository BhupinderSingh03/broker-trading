package com.codility.repository;

import org.springframework.data.repository.CrudRepository;

/**
 * WARNING: Do not modify the interface.
 * The file does not need to be submitted, it is only for your reference.
 */
public interface InventoryRepository extends CrudRepository<InventoryEntity, InventoryEntityId> {

}
