package com.codility.api;

import com.codility.services.OrderService;
import com.codility.model.requests.OrderRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * This is the entry point for all trading operations.
 */
@RestController
@RequestMapping("/orders")
public class TradingController {

    @Autowired
    private OrderService orderService;

    // POST - Create an order
    @PostMapping
    public ResponseEntity<?> createOrder(@RequestBody OrderRequest orderRequest) {
        return orderService.create(orderRequest);
    }

    // PUT - cancel an order
    @PutMapping("/{orderId}")
    public ResponseEntity<?> cancelOrder(@PathVariable Long orderId) {
        return orderService.cancelOrder(orderId);
    }

    // GET - get order by id
    @GetMapping("/{orderId}")
    public ResponseEntity<?> getOrder(@PathVariable Long orderId) {
        return orderService.getOrder(orderId);
    }

}
