package com.codility.services;

import com.codility.model.requests.OrderRequest;
import com.codility.repository.BuyingPowerEntity;
import com.codility.repository.BuyingPowerRepository;
import com.codility.exceptions.InsufficientPowerOrInventoryException;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Optional;

@Service
public class BuyingPowerService {

    @Autowired
    private BuyingPowerRepository buyingPowerRepository;

    public void subtractAmount(OrderRequest orderRequest, BigDecimal totalPrice){
        Optional<BuyingPowerEntity> buyingPowerEntity = buyingPowerRepository.findById(orderRequest.getPortfolioId());
        BuyingPowerEntity entity = buyingPowerEntity.orElseThrow(() -> new EntityNotFoundException("Insufficient buying power"));

        // verifying if the portfolio has enough power for the purchase
        if(entity.getAmount().compareTo(totalPrice) > 0){
            BigDecimal updatedAmount = entity.getAmount().subtract(totalPrice);
            BuyingPowerEntity buyingPowerEntityRequest = new BuyingPowerEntity(orderRequest.getPortfolioId(), updatedAmount);
            buyingPowerRepository.save(buyingPowerEntityRequest);
        } else{
           throw new InsufficientPowerOrInventoryException("Insufficient buying power");
        }
    }

    public void addAmount(String portfolioId, BigDecimal totalPrice){
        Optional<BuyingPowerEntity> buyingPowerEntity = buyingPowerRepository.findById(portfolioId);
        BuyingPowerEntity entity = buyingPowerEntity.orElseThrow(() -> new EntityNotFoundException("BuyingPowerEntity not found"));
        BigDecimal updatedAmount = entity.getAmount().add(totalPrice);
        BuyingPowerEntity buyingPowerEntityRequest = new BuyingPowerEntity(portfolioId, updatedAmount);
        buyingPowerRepository.save(buyingPowerEntityRequest);
    }
}
