package com.codility.services;

import com.codility.model.requests.OrderRequest;
import com.codility.repository.InventoryEntity;
import com.codility.repository.InventoryEntityId;
import com.codility.repository.InventoryRepository;
import com.codility.exceptions.InsufficientPowerOrInventoryException;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class InventoryService {

    @Autowired
    private InventoryRepository inventoryRepository;

    public void create(OrderRequest orderRequest) {
        InventoryEntity inventoryEntity = new InventoryEntity(orderRequest.getPortfolioId(), orderRequest.getIsin(), orderRequest.getQuantity());
        inventoryRepository.save(inventoryEntity);
    }

    public void delete(String portfolioId, String isin) {
        InventoryEntityId inventoryEntityId = new InventoryEntityId(portfolioId, isin);
        inventoryRepository.deleteById(inventoryEntityId);
    }

    public void checkInventory(OrderRequest orderRequest) {
        InventoryEntityId inventoryEntityId = new InventoryEntityId(orderRequest.getPortfolioId(), orderRequest.getIsin());
        Optional<InventoryEntity> inventoryEntity = inventoryRepository.findById(inventoryEntityId);

        if (inventoryEntity.isEmpty()) {
            throw new EntityNotFoundException("Insufficient inventory");
        }
        if (inventoryEntity.get().getQuantity().compareTo(orderRequest.getQuantity()) < 0) {
            throw new InsufficientPowerOrInventoryException("Insufficient inventory");
        }
    }

}
