package com.codility.services;

import com.codility.MarketDataService;
import com.codility.model.requests.OrderRequest;
import com.codility.model.responses.ErrorResponse;
import com.codility.model.responses.OrderResponse;
import com.codility.repository.*;
import com.codility.exceptions.InsufficientPowerOrInventoryException;
import com.codility.exceptions.OrderNotCreatedException;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Optional;

import static com.codility.OrderSide.BUY;
import static com.codility.OrderSide.SELL;
import static com.codility.OrderStatus.CANCELLED;
import static com.codility.OrderStatus.CREATED;

@Service
public class OrderService {

    @Autowired
    private MarketDataService marketDataService;

    @Autowired
    private InventoryService inventoryService;

    @Autowired
    private BuyingPowerService buyingPowerService;

    @Autowired
    private OrderRepository orderRepository;

    public ResponseEntity<?> create(OrderRequest orderRequest){
       if(orderRequest.getSide().equals(BUY)){
           return buyOrder(orderRequest);
       }else if(orderRequest.getSide().equals(SELL)) {
           return sellOrder(orderRequest);
       }else{
           ErrorResponse errorResponse = new ErrorResponse(400, "Incorrect side in the request");
           return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
       }
    }

    public ResponseEntity<?> buyOrder(OrderRequest orderRequest){
        BigDecimal price = marketDataService.getPrice(orderRequest.getIsin());
        BigDecimal totalPrice = price.multiply(orderRequest.getQuantity());
        totalPrice = totalPrice.setScale(2, RoundingMode.HALF_UP);

        try {
            inventoryService.create(orderRequest);
            buyingPowerService.subtractAmount(orderRequest, totalPrice);
            return ResponseEntity.ok(createOrder(orderRequest, totalPrice));
        }
        catch(InsufficientPowerOrInventoryException | EntityNotFoundException ex){
            ErrorResponse errorResponse = new ErrorResponse(400, ex.getMessage());
            return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
        }
        catch(Exception ex){
            ErrorResponse errorResponse = new ErrorResponse(500, "Internal Server Error");
            return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<?> sellOrder(OrderRequest orderRequest){
        BigDecimal price = marketDataService.getPrice(orderRequest.getIsin());
        BigDecimal totalPrice = price.multiply(orderRequest.getQuantity());
        totalPrice = totalPrice.setScale(2, RoundingMode.HALF_UP);

        try {
            inventoryService.checkInventory(orderRequest);
            return ResponseEntity.ok(createOrder(orderRequest, totalPrice));
        }
        catch(InsufficientPowerOrInventoryException | EntityNotFoundException ex){
            ErrorResponse errorResponse = new ErrorResponse(400, ex.getMessage());
            return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
        }
        catch(Exception ex){
            ErrorResponse errorResponse = new ErrorResponse(500, "Internal Server Error");
            return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }


    }

    public ResponseEntity<?> getOrder(Long orderId){

        try {
            Optional<OrderEntity> orderEntityResp = orderRepository.findById(orderId);
            OrderEntity entity = orderEntityResp.orElseThrow(() -> new EntityNotFoundException("Order not found"));
            return ResponseEntity.ok(mapEntityResponse(entity));
        }
        catch(EntityNotFoundException ex){
            ErrorResponse errorResponse = new ErrorResponse(404, ex.getMessage());
            return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
        }
        catch(Exception ex){
            ErrorResponse errorResponse = new ErrorResponse(500, "Internal Server Error");
            return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    public ResponseEntity<?> cancelOrder(Long orderId) {
        try {
            Optional<OrderEntity> orderEntityResp = orderRepository.findById(orderId);
            OrderEntity entity = orderEntityResp.orElseThrow(() -> new EntityNotFoundException("Order not found"));
            if (entity.getStatus().equals(CREATED)) {
                entity.setStatus(CANCELLED);
                orderRepository.save(entity);
                inventoryService.delete(entity.getPortfolioId(), entity.getIsin());
                buyingPowerService.addAmount(entity.getPortfolioId(), entity.getPrice());
               return ResponseEntity.ok("Order cancelled for orderId" + orderId);
            } else {
                throw new OrderNotCreatedException("Order cannot be cancelled");
            }

        } catch (OrderNotCreatedException ex) {
            ErrorResponse errorResponse = new ErrorResponse(400, ex.getMessage());
            return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
        }
        catch (EntityNotFoundException ex) {
            ErrorResponse errorResponse = new ErrorResponse(404, ex.getMessage());
            return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
        }
        catch (Exception ex) {
            ErrorResponse errorResponse = new ErrorResponse(500, "Internal Server Error");
            return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    private OrderResponse createOrder(OrderRequest orderRequest, BigDecimal totalPrice){
        OrderEntity orderEntity = prepareEntityRequest(orderRequest, totalPrice);
        OrderEntity orderEntityResp =  orderRepository.save(orderEntity);
        return mapEntityResponse(orderEntityResp);
    }

    private OrderEntity prepareEntityRequest(OrderRequest orderRequest, BigDecimal totalPrice){
        return new OrderEntity(orderRequest.getPortfolioId(), orderRequest.getIsin(), CREATED, orderRequest.getSide(), orderRequest.getQuantity(), totalPrice);
    }

    private OrderResponse mapEntityResponse(OrderEntity orderEntityResp){
        return new OrderResponse(orderEntityResp.getId(), orderEntityResp.getPortfolioId(), orderEntityResp.getIsin(), orderEntityResp.getSide(), orderEntityResp.getQuantity(), orderEntityResp.getPrice(), orderEntityResp.getStatus());
    }
}
