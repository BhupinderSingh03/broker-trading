package com.codility;

/**
 * WARNING: Do not modify the enum.
 * The file does not need to be submitted, it is only for your reference.
 */
public enum OrderStatus {
    CREATED, EXECUTED, CANCELLED
}
