package com.codility.exceptions;
public class InsufficientPowerOrInventoryException extends RuntimeException {
    public InsufficientPowerOrInventoryException(String message) {
        super(message);  // Pass the error message to the superclass
    }
}