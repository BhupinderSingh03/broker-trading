package com.codility.exceptions;
public class OrderNotCreatedException extends RuntimeException {
    public OrderNotCreatedException(String message) {
        super(message);  // Pass the error message to the superclass
    }
}